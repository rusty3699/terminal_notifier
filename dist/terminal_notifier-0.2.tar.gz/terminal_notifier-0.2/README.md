# terminal-notifier
  A command-line tool that provides multi-channel notifications (desktop, phone, email, popup) based on command outcomes (success, failure, user input required, crash).


## Installation

To install Command Notifier, you can use pip:

```bash
pip todecide


# for DEV
- to build and install
 python .\setup.py sdist bdist_wheel

 pip uninstall terminal-notifier
 pip install . 
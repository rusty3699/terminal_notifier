# terminal-notifier
  A command-line tool that provides multi-channel notifications (desktop, phone, email, popup) based on command outcomes (success, failure, user input required, crash).


## Installation

To install Command Notifier, you can use pip:

```bash
pip todecide

